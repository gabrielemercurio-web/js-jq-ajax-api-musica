$(document).ready(function() {
	//Code
});